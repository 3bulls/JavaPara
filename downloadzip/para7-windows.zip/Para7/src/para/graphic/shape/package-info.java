/**
 * 図形のクラス、図形属性のクラスをまとめたパッケージ
 */
package para.graphic.shape;
