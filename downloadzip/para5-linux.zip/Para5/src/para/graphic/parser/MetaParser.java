package para.graphic.parser;
import java.util.*;

public interface MetaParser{
  void parse(Scanner s);
}
